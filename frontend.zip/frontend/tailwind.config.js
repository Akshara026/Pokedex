module.exports = {
    content: ['./frontend/**/*.{html,js}'],
 // Scan files inside "frontend" folder
    theme: {
        extend: {}
    },
    plugins: [],
}